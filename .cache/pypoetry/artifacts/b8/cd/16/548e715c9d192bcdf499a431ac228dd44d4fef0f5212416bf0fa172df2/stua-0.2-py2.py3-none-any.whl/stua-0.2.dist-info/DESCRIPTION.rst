with no specific focus.

Home-page: https://bitbucket.org/rsalmaso/python-stua
Author: Raffaele Salmaso
Author-email: raffaele@salmaso.org
License: MIT
Description: UNKNOWN
Platform: UNKNOWN
Classifier: License :: OSI Approved :: MIT License
Classifier: Operating System :: OS Independent
Classifier: Programming Language :: Python
Classifier: Programming Language :: Python :: 2.7
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.2
Classifier: Programming Language :: Python :: 3.3
Classifier: Programming Language :: Python :: 3.4
Classifier: Topic :: Utilities
Classifier: Development Status :: 4 - Beta
