from colorama import init
init()

from colorama import Fore, Back, Style

def main():
    print(Fore.RED + "Hello")

if __name__ == '__main__':
    main()

